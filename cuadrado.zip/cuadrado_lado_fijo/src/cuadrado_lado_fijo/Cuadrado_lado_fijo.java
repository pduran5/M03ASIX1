/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cuadrado_lado_fijo;

/**
 *
 * @author Alumne
 */
public class Cuadrado_lado_fijo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      //se declaran las variables del programa
      int lado, area; //declaracion de variable (no tiene valor)    
      lado = 9; //le asigno un valor
      area = lado * lado;
      System.out.println("La area del cuadrado es : " + area);



   // TODO code application logic here
    }

}
