/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package helloworld;

/**
 *
 * @author Alumne
 */
public class HelloWorld {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //este programa va a decir buenos dias comentario
        /* Este programa comentario en varias lineas
            va a decir
           buenos dias*/
        System.out.print("Hello World!!! "); //escribir por pantalla
        System.out.println("Se acabo");
          //print muestra por pantalla sin poner return al final (nueva linea)
          //pprintln muestra por pantalla poniendo un return al final
    }

}
